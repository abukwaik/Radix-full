<?php
/*
Plugin Name: Rookie Core
Description: Required plugin for Rookie Theme
Version: 1.1
License: GPL2 or later
Author: Abukwaik
Author URI: http://www.croti.com
*/

/*  Copyright 2014  Rookie Team  (email : abukwaikabeer@gmail.com)

	This program is free software; you can redistribute it and/or modify
	it under the terms of the GNU General Public License, version 2, as 
	published by the Free Software Foundation.

	This program is distributed in the hope that it will be useful,
	but WITHOUT ANY WARRANTY; without even the implied warranty of
	MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
	GNU General Public License for more details.

	You should have received a copy of the GNU General Public License
	along with this program; if not, write to the Free Software
	Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA
*/

class rookie_core {
	function __construct() {
		add_action( 'plugins_loaded', array( &$this, 'rookie_plugin_constants'), 	1);
		add_action( 'plugins_loaded', array( &$this, 'rookie_plugin_lang'),			2);
		add_action( 'plugins_loaded', array( &$this, 'rookie_plugin_includes'), 	3);
		add_action(	'init', array( &$this,'rookie_init_shortcodes'));
	}
		
	function rookie_plugin_constants() {
		define( 'ROOKIE_PLUGIN_VERSION', '1.0' );
		define( 'ROOKIE_PLUGIN_WP_VERSION',   get_bloginfo( 'version' ));
		define( 'ROOKIE_PLUGIN_DIR', 	    ( plugin_dir_path( __FILE__ ) ) );
		define( 'ROOKIE_PLUGIN_URI', 		( plugin_dir_url( __FILE__ ) ) );
		define( 'CUSTOM_METABOXES_DIR', 	ROOKIE_PLUGIN_URI . '/includes/admin/metaboxes' );
		define(	'PLUGIN_IMG_DIR', 			ROOKIE_PLUGIN_DIR . 'images');
		define(	'PLUGIN_IMG_URI', 			ROOKIE_PLUGIN_URI . 'images');
		define( 'get_plugin_directory_uri', site_url() . '/wp-content/plugins/rookie-core');
	}

	function rookie_plugin_includes() {
		require_once ROOKIE_PLUGIN_DIR . '/includes/shortcodes/theme-shortcodes.php';
		require_once ROOKIE_PLUGIN_DIR . '/includes/shortcodes/manager/tinymce.php';
		require_once ROOKIE_PLUGIN_DIR . '/includes/social-share.php';
		require_once ROOKIE_PLUGIN_DIR . '/includes/admin/metaboxes/meta_box.php';	
		require_once ROOKIE_PLUGIN_DIR . '/includes/add-ons.php';
		include_once ROOKIE_PLUGIN_DIR . '/includes/importer/importer.php';
		
		if ( !class_exists( 'ReduxFramework' ) ) {
		  	require_once ROOKIE_PLUGIN_DIR . '/includes/redux-core/framework.php';
		  	require_once ROOKIE_PLUGIN_DIR . '/includes/redux-config.php';
		}
	}
		
	function rookie_plugin_lang() {
	}

	function rookie_init_shortcodes() {
	}
	
}

$rookie_core = new rookie_core();