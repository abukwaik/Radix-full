<?php
/**
 * Shortcodes functions
 * @package Rookie
 * @author Abukwaik http://www.croti.com
 * @since rookie 1.0
 *
 */

/**
    container
*/
add_shortcode( 'sh_container', function( $atts, $content = null ) {
  $atts = shortcode_atts(
    array(
      'class'        => '',
      'id'           => ''
      ), $atts);
  
  extract($atts);

  if($id!='') $id = 'id="' . $id . '"';

  return '<section ' . $id . ' class="' . $class . '"><div class="container-fluid"><div class="row-fluid">' . do_shortcode( $content ) . '</div></div></section>';
});


/**
    Columns
*/
add_shortcode( 'sh_column', function( $atts, $content = null ) {
  $atts = shortcode_atts(
    array(
      'size' => '',
      'animation' => '',
      'iteration' => '',
      'delay'     => '',
      'duration'  => '',
      ), $atts);
    extract($atts);

  $output = '';
  if($atts['animation'] !=='' ){
    $animation = 'wow ' . $atts['animation'] . '" data-wow-delay="' . $atts['delay'] . 's" data-wow-duration="' .$atts['duration']. 's" data-wow-iteration="' . $atts['iteration'].'';
  }

  $output .= '<div class="col-md-' .$atts['size']. ' ' . $animation . '">';
  $output .= do_shortcode( str_replace('<p></p>', '', $content) );
  $output .= '</div>';
  
  return $output;
});


/**
    Alert
*/
add_shortcode( 'sh_alert', function( $atts, $content = null ){
  $atts = shortcode_atts(
    array(
      'type'      => 'info',
      'dismiss'   => 'no',
      'title'     => '',
      'text_area' => '',
      'icon'      => '',
      'size'      => '',
      'align'     => '',
      'animation' => '',
      'delay'     => '',
      'iteration' => '',
      'duration'  => '',
      ), $atts);

  $animation = '';
  if($atts['animation'] !=='' ){
    $animation = 'wow ' . $atts['animation'] . '" data-wow-delay="' . $atts['delay'] . 's" data-wow-duration="' .$atts['duration']. 's" data-wow-iteration="' . $atts['iteration'].'';
  }

  $output = '<div class="alert '
  .  (($atts['type']=='none' ) ? '':' alert-'.$atts['type']) 
  .  (($atts['dismiss']=='no' ) ? '':' alert-dismissable')  
  .' fade in ' . $animation . '">';

  if($atts['dismiss']=='yes' ){
    $output .='<button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>';
  }

  $icon_set = $atts['icon'] . ' ' . $atts['size'] . ' ' . $atts['align'];

  $font = '';
  if( $atts['icon']!='' ){
    $font .= '<i class="fa fa-' . $icon_set . 'center-block"></i>';
  }

  if( $atts['title']!='' ){
    $output .= $font . '<h4>'. $atts['title']. '</h4>';
  }

  $output .= $atts['text_area'];
  $output .='</div>';
  return $output;
});


/**
    Blockquote
*/
add_shortcode( 'sh_blockquote', function( $atts, $content = null ){
  $atts = shortcode_atts(
    array(
      'text_area' => '',
      ), $atts);
  
  $output = '';
  if( $atts['text_area']!='' ){
    $output .='<blockquote class="blockquote">'. $atts['text_area']. '</blockquote>';
  }

 return $output;
});


/**
    Background section
*/
add_shortcode( 'sh_section_background', function( $atts, $content = null ){
  $atts = shortcode_atts(
    array(
      'title'         => '',
      'text_area'     => '',
      'img_src'       => '/images/fixed-bg.jpg',
      'button'        => '',
      'button_text'   => 'Button',
      'button_url'    => '#',
      'button_class'  => 'default',
      'button_icon'   => 'vimeo-square',
      'target'        => '_self',
      ), $atts);
    extract($atts);

    $output ='';
    $icon ='';

    if($button_icon) $icon = '<i class="fa fa-' . $button_icon . '"></i> ' . $button_text;
    if($button) $button = '<a target="' . $target . '" href="' . $button_url . '" class="btn btn-' . $button_class . ' wow fadeInDown" data-wow-delay="2s">' . $icon . '</a>';
    
    $output .='
    <section class="bg-section text-center" style="background: url('.$img_src.') center center no-repeat fixed;
    background-position: 50%;
    background-size: cover;
    margin: 0 auto;">
      <h2 class="wow fadeInDown">' . $title . '</h2>
      <p data-wow-delay=".5s" class="wow fadeInDown">' . $text_area . '</p>
      ' . $button . '
    </section>
  ';
  return $output;
});


/**
    Dropcap
*/
add_shortcode( 'sh_dropcap', function( $atts, $content = null ){
  $atts = shortcode_atts(
    array(
      'text_area' => '',
      ), $atts);
  
  $output ='';

  if( $atts['text_area']!='' ){
    $output .='<p class="dropcap">'. $atts['text_area']. '</p>';
  }

  return $output;
});


/**
    Portfolio 
 */
add_shortcode( 'sh_portfolio', function( $atts, $content = null ){
  $atts = shortcode_atts(
    array(
      'col' => '3 Columns'
      ), $atts);
    extract($atts);

  $args = array(
    'posts_per_page' => -1,
    'post_type'      =>  'portfolio'
  );

 $portfolios = get_posts( $args );

 ob_start();

  if(count($portfolios)>0) { ?>

  	<div class="row-fluid">
  		<ul class="portfolio-filter unstyled">
  			<li><a class="btn btn-default active" href="#" data-filter="*"><?php _e('All', 'rookie'); ?></a></li>
  			<?php 
  			$terms = get_terms('portfolio-categories', array('hide_empty'=> true));
  			foreach ($terms as $term) { ?>
  			<li><a class="btn btn-default" href="#" data-filter=".<?php echo $term->slug; ?>"><?php echo $term->name; ?></a></li>
  			<?php } ?>
  		</ul> <!-- portfolio-filter -->
  	</div>
  	<div class="row-fluid">
  		<div class="portfolio-inner">
  			<ul class="portfolio-items col-<?php echo $col; ?> unstyled">
  				<?php foreach ($portfolios as $key => $value) { ?>
  				<?php 
  				$terms = wp_get_post_terms( $value->ID, 'portfolio-categories' );
  				$new_terms = array();
  				foreach ($terms as $term) $new_terms[] = $term->slug;
  				$slugs = implode(' ', $new_terms);
  				?>
  				<li class="portfolio-item <?php echo $slugs; ?>">
  					<div class="item-main">
  						<div class="portfolio-image">
  							<?php echo get_the_post_thumbnail( $value->ID, 'medium-thumb', array('class' => 'img-responsive')); ?>
  							<div class="overlay">
  								<?php 
  								$full_img = wp_get_attachment_image_src( get_post_thumbnail_id($value->ID), 'full');
  								$img_src= $full_img[0];
  								?>
  								<a class="preview" href="<?php echo $img_src; ?>" data-gal="prettyPhoto"><i class="fa fa-eye"></i></a>
  								<a class="preview-link" href="<?php echo get_permalink( $value->ID ); ?>"><i class="fa fa-link"></i></a>
  							</div>
  						</div>
  						<div class="portfolio-title">
  							<a href="<?php echo get_permalink( $value->ID ); ?>"><h5><?php echo $value->post_title; ?></h5></a>  						</div>
  					</div>
  				</li>
  				<?php } ?>
  			</ul>
  		</div> <!-- portfolio-inner-->
  	</div> <!-- row-fluid -->
  <?php }
  return ob_get_clean();
});


/**
    Team
*/
add_shortcode( 'sh_team', function( $atts, $content = null ){

  $atts = shortcode_atts(
    array(
      'col' => '3'
      ), $atts);
    extract($atts);

  ob_start();
  $args = array(
    'posts_per_page' => -1,
    'post_type'      => 'rookie_team'
  );

  $data = get_posts( $args );

  if(count($data)>0){ ?>
    <div class="row">
      <?php foreach ($data as $key => $value) { ?>

      <div class="col-md-<?php echo round(12/count($data)); ?>">
        <div itemtype="https://schema.org/Person" itemscope="itemscope" class="team-member">
          <div class="team-img-container">
            <?php 
            if(count($data)==3) {
              echo get_the_post_thumbnail( $value->ID, 'medium-thumb', array('class' => 'img-responsive'));
            }
            elseif(count($data)==4) {
              echo get_the_post_thumbnail( $value->ID, 'team-four', array('class' => 'img-responsive'));
            }
            else {
              echo get_the_post_thumbnail( $value->ID, 'full-size', array('class' => 'img-responsive'));
            }
            ?>
            <div class="team-social">
              <ul class="team-social-bar unstyled">
                <?php if(get_post_meta($value->ID, 'team_facebook', true)!=''){ ?>
                <li>
                  <a class="facebook" href="<?php echo get_post_meta($value->ID, 'team_facebook', true)?>"><i class="fa fa-facebook"></i></a>            
                </li>
                <?php } ?>
                <?php if(get_post_meta($value->ID, 'team_twitter', true)!=''){ ?>
                <li>
                  <a class="twitter" href="<?php echo get_post_meta($value->ID, 'team_twitter', true)?>"><i class="fa fa-twitter"></i></a>                        
                </li>
                <?php } ?>     
                <?php if(get_post_meta($value->ID, 'team_gplus', true)!=''){ ?>
                <li>
                  <a class="google_plus" href="<?php echo get_post_meta($value->ID, 'team_gplus', true)?>"><i class="fa fa-google-plus"></i></a>
                </li>
                <?php } ?>
                <?php if(get_post_meta($value->ID, 'team_linkedin', true)!=''){ ?>
                <li>
                  <a class="linkedin" href="<?php echo get_post_meta($value->ID, 'team_linkedin', true)?>"><i class="fa fa-linkedin"></i></a>                        
                </li>
                <?php } ?>
                <?php if(get_post_meta($value->ID, 'team_pinterest', true)!=''){ ?>
                <li>
                  <a class="pinterest" href="<?php echo get_post_meta($value->ID, 'team_pinterest', true)?>"><i class="fa fa-pinterest"></i></a>                        
                </li>
                <?php } ?>
              </ul> <!-- .team-social-bar --> 
            </div> <!-- .team-social --> 
          </div><!-- .team-img-container --> 
          <h4 itemprop="name" class="team-member-name"><?php echo $value->post_title; ?></h4>
          <?php if(get_post_meta($value->ID, 'team_designation', true)!='') { ?>
          <div itemprop="jobTitle" class="team-member-job-title ">
            <?php echo get_post_meta($value->ID, 'team_designation', true) ?>
          </div>
          <?php } ?>
          <div itemprop="description" class="team-member-description ">
            <?php echo wpautop( $value->post_content ); ?>
          </div>
        </div>
      </div> <!-- end col --> 
      <?php } ?>
    </div> <!-- end row -->

  <?php } else { ?>
  <div class="alert alert-danger fade in">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <?php _e('No Team found!', 'rookie'); ?>
  </div>
  <?php
  }
  return ob_get_clean();
});


/**
    Buttons
*/
add_shortcode( 'sh_button', function( $atts, $content = null ){
  $atts = shortcode_atts(
    array(
      'text'      => 'Button',
      'size'      => '',
      'url'       => '#',
      'class'     => '',
      'icon'      => '',
      'target'    => '_self',
      'animation' => '',
      'iteration' => '',
      'delay'     => '',
      'duration'  => '',
      ), $atts);
  extract($atts);

  if($atts['animation'] !=='' ){
    $animation = 'wow ' . $atts['animation'] . '" data-wow-delay="' . $atts['delay'] . 's" data-wow-duration="' .$atts['duration']. 's" data-wow-iteration="' . $atts['iteration'] . '';
  }

  $classes  = 'btn';
  $output   = $text;

  if($size) $classes .= ' btn-'. $size;
  if($class) $classes .= ' btn-'. $class;
  if($icon) $output = '<i class="fa fa-' . $icon . '"></i> ' . $text;


  return '<a target="' . $target . '" href="' . $url . '" class="' . $classes . ' ' . $animation . '">' .  do_shortcode($output)  . '</a>';
});


/**
    Progressbar
*/
add_shortcode('sh_progressbar', function ( $atts, $content = null ){
  extract(shortcode_atts(array(
    'style' => '',
    'strip' => '',
    'animate' => '',
    'width' => '',
    'content' => '',
    ), $atts));

  $strip = ($strip == 'yes') ? 'progress-striped' : '';
  $animate = ($animate == 'yes') ? 'active' : '';
  // $style = ($style <> '') ? "progress-$style" : '';

  $out = '  <div class="progress-bar-wrapper">
    <span class="progress-header">' . do_shortcode($content) . '</span>
    <div class="progress ' . $strip . ' ' . $animate . '">
    <span class="progress-bar progress-bar-' . $style . '" role="progressbar" style="width: 0%" data-percentage="' . $width . '"></span>
    </div>
  </div>';
  return $out;
});

/**
    Divider
*/
add_shortcode( 'sh_divider', function( $atts, $content = null ){
  $atts = shortcode_atts(
    array(
      'style'  => ''
      ), $atts);

  extract($atts);
  return '<div class="clearfix ' . $style . '"></div>';
});

/**
    Accordion
 */
add_shortcode( 'sh_accordion', function( $atts, $content = null ){

  ob_start();

  $atts = shortcode_atts(
    array(
      'category' => 0,
      ), $atts);

  extract($atts);

  $args = array(   
    'post_type'=>'rookie_accordion',
    'orderby' => 'menu_order',
    'order' => 'ASC'
    );

  if( $category > 0 ){
    $args['tax_query'] = array(
      array(
        'posts_per_page' => -1,
        'taxonomy' => 'accordion-categories',
        'field' => 'term_id',
        'terms' => $category
        )
      );
  }

  $id = $category;
  $accordions = get_posts( $args );
  if(count($accordions)>0){ ?>
  <div id="accordion">
    <div class="panel-group" id="panel-<?php echo $id; ?>">
      <?php foreach ($accordions as $key => $value) { ?>
      <div class="panel panel-default">
        <div class="panel-heading <?php echo ($key==0)? 'active': ''; ?>" >
          <h4 class="panel-title">
            <a class="accordion-toggle" data-toggle="collapse" data-parent="#panel-<?php echo $id ?>" href="#accordion-<?php echo $value->ID . $category; ?>">
              <?php echo do_shortcode( $value->post_title ); ?>
            </a>
          </h4>
        </div>
        <div id="accordion-<?php echo $value->ID . $category; ?>" class="panel-collapse collapse <?php echo ($key==0)? 'collapse in':'collapse'; ?>">
          <div class="panel-body">
            <?php echo wpautop( $value->post_content ); ?>
          </div>
        </div>
      </div>
      <?php } ?>
    </div>
  </div>
  <?php } else { ?>
  <div class="alert alert-danger fade in">
    <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
    <?php _e('No item found!', 'rookie'); ?>
  </div>
  <?php }
  return ob_get_clean();
});

/**
    Pricing
*/
add_shortcode( 'sh_pricing', function( $atts, $content = null ){
  ob_start();
  $atts = shortcode_atts(
    array(
      'category' => '0'
      ), $atts);

  extract($atts);

  $args = array(
    'post_type'=>'rookie_pricing', 
    'orderby' => 'menu_order',
    'order' => 'ASC',
    );

  if( $category > 0 ){
    $args['tax_query'] = array(
      array(
        'posts_per_page' => -1,
        'taxonomy' => 'cat_pricing',
        'field' => 'term_id',
        'terms' => $category
        )
      );
  }

  $pricings = get_posts( $args );

  if(count($pricings)>0) {
    ?>
    <div class="row pricing-tables">
      <?php foreach ($pricings as $key => $value) { ?>
      <?php $featured = get_post_meta($value->ID, 'pricing_featured',true); ?>
      <div class="col-md-<?php echo round(12/count($pricings)); ?>">
        <ul class="plan<?php echo ($featured==1)? ' featured' : ''; ?>">
          <li class="plan-name">
            <h3><?php echo $value->post_title; ?></h3>
          </li>
          <li class="plan-price">
            <div>
              <span class="price"><?php echo get_post_meta($value->ID, 'pricing_price',true) ?></span>
              <small><?php echo get_post_meta($value->ID, 'pricing_duration',true) ?></small>
            </div>
          </li>
          <li class="plan-details"><?php echo $value->post_content; ?></li>
          <li class="plan-button-box">
            <a class="btn btn-default" href="<?php echo get_post_meta($value->ID, 'pricing_button_url',true) ?>"><?php echo get_post_meta($value->ID, 'pricing_button_text',true) ?></a>
          </li>
        </ul>
      </div>
      <?php } ?>
    </div>
    <?php
  } else {
    ?>
    <div class="alert alert-danger fade in">
      <button type="button" class="close" data-dismiss="alert" aria-hidden="true">&times;</button>
      <?php _e( 'No pricing table found!', 'rookie' ); ?>
    </div>
    <?php
  }
  wp_reset_postdata();

  return ob_get_clean();
});

/**
    Recent Works
*/
add_shortcode( 'sh_recent_works', function( $atts, $content= null ){
  ob_start();

  $atts = shortcode_atts(array(
    'slides'        => '3',
    'title'         => '',
    'description'   => ''
    ), $atts);

  extract($atts);

  $item_per_slide   = $slides;

  $args             =  array(
    'numberposts'   =>  $item_per_slide*$slides,
    'orderby'       =>  'menu_order',
    'order'         =>  'ASC',
    'post_type'     =>  'portfolio'
    );

  $portfolios = get_posts( $args );
  $i      = 1;
  $j      = 1;
  $count  = count($portfolios);

  if ($count>0) { ?>

    <div id="recent-works" class="row">

      <div class="col-md-3">
        <div class="recent-work-inner">
          <h3><?php echo $title; ?></h3>
          <p><?php echo $description; ?></p>
          <div class="btn-group">
            <a class="btn btn-default" href="#slider" data-slide="prev"><i class="fa fa-angle-left"></i></a>
            <a class="btn btn-default" href="#slider" data-slide="next"><i class="fa fa-angle-right"></i></a>
          </div>
        </div>
      </div>
      <div class="col-md-9">
        <div id="slider" class="carousel slide">
          <div class="carousel-inner">
            <?php foreach( $portfolios as $key=>$value ) {
              if( (($key+1)%($item_per_slide)==0) || $j== $count) {
                $lastContainer= true;
              } else {
                $lastContainer= false;
              }
              if($i==1){ ?>
              <div class="item <?php echo ($key==0)? 'active': ''; ?>">
                <div class="row">
                  <?php } ?>
                  <div class="col-sm-<?php echo round(12/($item_per_slide)); ?>">
                    <div class="portfolio-item">
                      <div class="item-main">

                        <div class="portfolio-image">
                          <?php echo get_the_post_thumbnail( $value->ID, 'medium-thumb', array('class' => 'img-responsive')); ?>
                          <div class="overlay">
                            <?php 
                            $full_img = wp_get_attachment_image_src( get_post_thumbnail_id($value->ID), 'full');
                            $img_src= $full_img[0];
                            ?>
                            <a class="preview" href="<?php echo $img_src; ?>" data-gal="prettyPhoto"><i class="fa fa-eye"></i></a>
                            <a class="preview-link" href="<?php echo get_permalink( $value->ID ); ?>"><i class="fa fa-link"></i></a>
                          </div>
                        </div>
                        <div class="portfolio-title">
                          <a href="<?php echo get_permalink( $value->ID ); ?>"><h5><?php echo $value->post_title; ?></h5></a>
                        </div>
                      </div><!--.portfolio-item-->
                    </div>
                  </div>
                  <?php if(($i == $item_per_slide) || $lastContainer) { ?>
                </div><!--/.row-->
              </div><!--/.col-xs-->
                  <?php $i=0; }
                    $i++;
                    $j++;
                  } ?>
          </div>
        </div> <!-- scroller -->
      </div> <!--/.col-md-9-->
    </div> <!-- end row -->
      <?php }
    return ob_get_clean();
});

/** 
    Tabs
*/
add_shortcode ('tabgroup', function( $atts, $content = null ) {
  extract(shortcode_atts(array(
    'style' => 'horizontal',
    ), $atts));

  $GLOBALS['tab_count'] = 0;
  $i = 1;
  $id = rand();

  do_shortcode( $content );

  if( is_array( $GLOBALS['tabs'] ) ){
    foreach( $GLOBALS['tabs'] as $tab ){  
      $tabs[] = '<li><a href="#panel'.$id.$i.'" data-toggle="tab">' .$tab['title']. '</a></li>';
      $panes[] = '<div class="tab-pane fade" id="panel'.$id.$i.'">' .$tab['content']. '</div>';
      $i++;
    }

    $output = '<div class="tab-container"><ul id="tabs" class="nav nav-tabs" data-tabs="tabs">'.implode( "\n", $tabs ).'</ul><div class="tab-content">'.implode( "\n", $panes ).'</div></div>';
  }

  return $output;
});

add_shortcode ('tab', function( $atts, $content = null) {
  extract(shortcode_atts(array(
    'title' => '',
    ), $atts));
  
  $x = $GLOBALS['tab_count'];
  $GLOBALS['tabs'][$x] = array( 'title' => sprintf( $title, $GLOBALS['tab_count'] ), 'content' =>  do_shortcode( $content) );
  $GLOBALS['tab_count']++;
});

/** 
    Call To action
*/
add_shortcode( 'sh_call_to_action', function( $atts, $content = null ){
  $atts = shortcode_atts(
    array(
      'style'   => '',
      'title'   => '',
      'text_area'    => '',
      'url'     => '#',
      'url_text'  => 'Get started',
      'target'  =>'_self',
      'animation' => '',
      'iteration' => '',
      'delay'     => '',
      'duration'  => '',
      ), $atts);
  extract($atts);

  if($atts['animation'] !=='' ){
    $animation = 'wow ' . $atts['animation'] . '" data-wow-delay="' . $atts['delay'] . 's" data-wow-duration="' .$atts['duration']. 's" data-wow-iteration="' . $atts['iteration'].'';
  }

  if( $atts['style']=='1' ) {
    return '
    <div class="get-started text-center clearfix ' . $animation . '">
      <h2>' . $title . '</h2>
      <p>' . $text_area . '</p>
      <div class="request">
        <a target="' . $target . '" href="' . $url . '">' . $url_text . '</a>
      </div>
    </div>';
  }

  if( $atts['style']=='2' ) { 
    return '
    <div class="get-started-2 clearfix ' . $animation . '">
      <div class="col-md-10">
        <h2>' . $title . '</h2>
        <p>' . $text_area . '</p>
      </div>
      <div class="col-md-2">
        <a target="' . $target . '" data-align="right" data-position="top-left" data-size="" class="circlebtn with-symbol" href="' . $url . '"><span class="text">' . $url_text . '</span><span class="symbol"><img alt="ok" src="data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAAEAAAABACAMAAACdt4HsAAAAYFBMVEUAAAD///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////98JRy6AAAAH3RSTlMA/BAIAvecf0MeuHDx3+aKLxbLKOnUrWReTtnCkVU24mhdZAAAAXBJREFUWMPl1suSgjAQheEkQEhArl5AUPv933LKsaxyPE3pkd34LS2zaTo/mK/jyjyuOj+JZHliPnaSq+r46fnWyk2xNR+Z5S5rnOGd5UE9puz5pJI/+ovh5PLENtT5mAloDeEgKBDng6CNIyY4CcrN+0pBE7HT3UYQs9FeUEGcv1gBGXEf0l4Qs0WDoNoRGdkJGqmMoJk4v7UCLHMLCkGeOH/ULkFHZQSVVEbQPqUygsLKjBxWZiSLCwvvfYTf9kRGSnjt6RmpFjISf5NRDymXEdy3fSAzgq+t4r7nrZ6R1zfW+tumzkRG/NOuX6c5EhkJ+M8x1lpGiAuj6RcuQSPvsZcXXy6veCLaQmQkiIbIiJsFcRk541MgM5KUcG3YjHTeikLPiK6F/tNfI8dJVHpG9FHsZMHZvMed9FEUxKtUG4Wlvs4DpvhkKOnwNIqdMyTXZPJgMLx4gIywQo8ZYUdRQ0ZIyXUUVWdWiHnpzH/3Aw34mVEwmhGuAAAAAElFTkSuQmCC"></span></a>
      </div>
    </div>
    ';
  }
});

/**
		Service Box
*/
add_shortcode( 'sh_service_box', function( $atts, $content=null ){
  $atts = shortcode_atts(array(
    'style'     => '',
    'icon' 		  => '',
    'icon_size' => '',
    'title' 		=> '',
    'text_area' => '',
    'align' 	  => '',
    'url'       => '',
    'url_text'  => '',
    'target'    =>'_self',
    'animation' => '',
    'iteration' => '',
    'delay'     => '',
    'duration'  => '',
    ), $atts);
  extract($atts);

  if($atts['animation'] !=='' ){
    $animation = 'wow ' . $atts['animation'] . '" data-wow-delay="' . $atts['delay'] . 's" data-wow-duration="' .$atts['duration']. 's" data-wow-iteration="' . $atts['iteration'].'';
  }

  if( $atts['style']=='1' ) {
    return '
    <div class="default-service-box ' . $animation . '">
      <div class="default-service-icon ' . $align .'">
        <i class="fa fa-' . $icon . ' ' . $icon_size . ' ' . $align .'"></i>
        <h4>' . $title . '</h4>
        <div class="default-service-icon-content">
          <p>' . $text_area . '</p>
        </div>
        <a target="' . $target . '" href="' . $url . '"><span class="read-more">' . $url_text . '</span></a>
        <div class="clearfix"></div>
      </div>
    </div>
    ';
  }

  $output ='';

  if( $atts['style']=='2' ) {

    $output .= '
    <div class="circle-service-box ' . $animation . '">
      <div class="circle-service-icon ' . $align .'">
        <div class="circle-box-heading">
          <div class="circle-box-icon">
            <i class="fa fa-' . $icon . ' ' . $icon_size . '"></i>
          </div>
          <h3 class="content-box-heading">' . $title . '</h3>
        </div>
        <div class="content-container">' . $text_area . '</div>';

        if( $atts['url']!='' ){
          $output .='<a class="btn btn-sm btn-default" target="' . $target . '" href="' . $url . '">' . $url_text . '</a>';
        }
        
       $output .= '<div class="clearfix"></div>
      </div>
    </div>
    ';
  return $output;

  }

  if( $atts['style']=='3' ) {
    return '
    <div class="boxed-service-box text-center ' . $animation . '">
      <h4>' . $title . '</h4>
          <div class="boxed-service-icon">
            <i class="fa fa-' . $icon . ' ' . $icon_size . '"></i>
          </div>
        <p>' . $text_area . '</p>
      <a target="' . $target . '" href="' . $url . '"><span class="read-more">' . $url_text . '</span></a>
    </div>
    ';
  }
});

/**
    Icons
*/
add_shortcode( 'sh_icons', function( $atts, $content=null ){
  $atts = shortcode_atts(array(

    'font'    => '',
    'size'    => '',
    'spin'    => '',
    'border'  => '',
    'align'   => '',
    
    ), $atts);
  extract($atts);
  $icon = $font . ' ' . $size . ' ' . $spin . ' ' . $border . ' ' . $align;
  return '<i class="fa fa-' . $icon . '">' . do_shortcode( str_replace('<p></p>', '', $content) ). '</i>';
});

/**
    Recent posts
*/

add_shortcode( 'sh_latest_news', function( $atts, $content=null ){
  $atts = shortcode_atts(array(
    'category'    => '0',
    ), $atts);
  extract($atts);
  global $post;
  $output = '';
  $my_query = new WP_Query( array(
   'post_type' => 'post',
   'posts_per_page' => 1
   ));
  if( $my_query->have_posts() ) : while( $my_query->have_posts() ) : $my_query->the_post();
  $output .='
  <div class="latest-blog-list clearfix">
    <div class="blog-list-item-date">'.get_the_time('d', $post->ID).'<span>'.get_the_time('M', $post->ID).'</span>
    </div>
    <div class="blog-list-item-description">
      <a href="'. get_permalink() .'"><h4>' . get_the_title() . '</h4></a>
      <span><i class="fa fa-comment"></i> '.get_comments_number($post->ID).' Comments</span>
      <div class="blog-list-item-excerpt">'. get_the_excerpt() . ' .. <a class="small" href="'. get_permalink() .'">' . __( "Continue reading", "rookie" ) . ' &rarr;</a>
      </div>
    </div>
  </div>
  ';
  endwhile; endif;
  return $output;
});

/**
    List Shortcodes
*/

add_shortcode ( 'list', function ( $atts, $content = null ) {
  $out = '<ul class="list-arrow unstyled">'. do_shortcode($content) . '</ul>';
    return $out;
});

add_shortcode ( 'list_item', function ( $atts, $content = null ) {
  $out = '<li>' . do_shortcode($content) . '</li>';
    return $out;
});

/**
    Google Maps
*/

// add_shortcode ('sh_google_maps', function ($atts, $content = null) {
//   extract(shortcode_atts(array(
//     "width" => '640',
//     "height" => '480',
//     "url" => ''
//     ), $atts));
//   return '<div class="google-map"><iframe width="'.$width.'" height="'.$height.'" frameborder="0" scrolling="no" marginheight="0" marginwidth="0" src="'.$url.'&output=embed"></iframe></div>';
// });


/**
    
    Cleaning Function

*/

// Enable Shortcodes In Sidebar Widgets
add_filter('widget_text', 'do_shortcode');

// Intelligently remove extra P and BR tags around shortcodes that WordPress likes to add
function rookie_fix_shortcodes($content){   
  $array = array (
    '<p>[' => '[', 
    ']</p>' => ']', 
    ']<br />' => ']',
    ']<br>' => ']'
    );

  $content = strtr($content, $array);
  return $content;
}

add_filter('the_content', 'rookie_fix_shortcodes');

function rookie_cleanup_domdocument($content) {
  $content = preg_replace('#(( ){0,}<br( {0,})(/{0,1})>){1,}$#i', '', $content);
  return $content;
}
