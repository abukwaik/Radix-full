<?php

/**
* @package rookie color classes
* @since rookie 1.0
* 
*/

$color_classes = array(
	'' 				=> 'None',
	'white' 		=> 'White',
	'rookie' 		=> 'Rookie',
	'bg-section' 	=> 'Img Background',
	'alizarin' 		=> 'Alizarin',
	'asbestos' 		=> 'Asbestos',
	'amethyst' 		=> 'Amethyst',
	'belize-hole' 	=> 'Belize Hole',
	'carrot' 		=> 'Carrot',
	'clouds' 		=> 'Clouds',
	'concrete' 		=> 'Concrete',
	'emerald' 		=> 'Emerald',
	'green-sea'		=> 'Green Sea',
	'midnight-blue' => 'Midnight Blue',
	'nephritis' 	=> 'Nephritis',
	'sun-flower' 	=> 'Sun Flower',
	'silver' 		=> 'Silver',
	'turquoise' 	=> 'Turquoise',
	'orange' 		=> 'Orange',
	'pumkin' 		=> 'Pumkin',
	'peter-river' 	=> 'Peter River',
	'pomegranate' 	=> 'Pomegranate',
	'wisteria' 		=> 'Wisteria',
	'wet-asphalt' 	=> 'Wet Asphalt',
	);