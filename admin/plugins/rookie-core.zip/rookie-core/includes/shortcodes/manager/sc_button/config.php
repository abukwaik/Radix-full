<?php
/**
 *
 * @package rookie Shortcodes configuration
 * @since rookie 1.0
 *
 */

require_once('font-awesome.php');
require_once('color-classes.php');
require_once('animation.php');

// Get accordion Categories
$terms = array(__('All categories', 'rookie'));
foreach(get_terms('accordion-categories', 'orderby=count&hide_empty=0') as $term ){

    $terms[$term->term_id] = $term->name;
} 


$shortcodes = array(

	// Container
	array(
		'id'=>'Container',
		'type'=>'simple', 
		'description'=>__('Colored Container', 'rookie'),
		'fields'=>array(
			array(
				'id' =>'class',
				'type'=>'select',
				'description'=>__('Select Color Class', 'rookie'),
				'options'=> $color_classes,
				),

			array(
				'id' =>'id',
				'type'=>'text', 
				'description'=>__('Choose a Unique ID (optional)', 'rookie')
				),
			)
		),

	// Column
	array(
		'id'=>'Column',
		'type'=>'simple', 
		'description'=>__('Column', 'rookie'),
		'fields'=>array(
			array(
				'id' =>'Size',
				'type'=>'select',
				'description'=>__('Select Column Size', 'rookie'),
				'options'=>array(
					'1'  => '1/12 Column',
					'2'  => '2/12 Columns',
					'3'  => '3/12 Columns',
					'4'  => '4/12 Columns',
					'5'  => '5/12 Columns',
					'6'  => '6/12 Columns',
					'7'  => '7/12 Columns',
					'8'  => '8/12 Columns',
					'9'  => '9/12 Columns',
					'10' => '10/12 Columns',
					'11' => '11/12 Columns',
					'12' => '12/12 Columns',
					)
				),
			array(
				'id' =>'Animation',
				'type'=>'select',
				'description'=>__('Select animation', 'rookie'),
				'options'=> $Animation,
				),
			array(
				'id' => 'Delay',
				'type'=>'text',
				'description'=> __('Delay before the animation starts in second. eg. 0.5 or 1', 'rookie'),
				),
			array(
				'id' => 'Iteration',
				'type'=>'text',
				'description'=> __('Number of times the animation is repeated. eg. 5', 'rookie'),
				),
			array(
				'id' => 'Duration',
				'type'=>'text',
				'description'=> __('Animation duration in second. eg. 0.5 or 1', 'rookie'),
				),
			)
		),

	// Accordion
	array(
		'id' => 'Accordion',
		'description' => __('Add an Accordion' , 'rookie'),
		'fields'=>array(
			array(
				'type'=>'desc', 
				'description' => __('This shortcode will display the content created by "Accordion" Post inside of your Admin Panel' , 'rookie'),
				),

			array(
				'id' =>'Category',
				'type'=>'select', 
				'description' => __('Accordion Categories' , 'rookie'),
				'options'=> $terms,
				),
			),

		),

	// Alert
	array(
		'id' => 'Alert' ,
		'description' => __('Bootstrap Alert Style' , 'rookie'),
		'fields'=>array(
			array(
				'id' =>'Type',
				'type'=>'select', 
				'description' => __('Alert Style' , 'rookie'),
				'options'=>array(
					'success'   =>'Success',
					'info'   	=>'Info',
					'warning'   =>'Warning',
					'danger'   	=>'Danger',
					'default'   =>'Default',
					)
				),
			array(
				'id' =>'Dismiss',
				'type'=>'select',
				'description' => __('Show Close Button' , 'rookie'),
				'options'=>array(
					'yes' 	=> 'Yes',
					'no' 	=> 'No',
					)
				),
			array(
				'id' =>'Title',
				'type'=>'text',  
				'description' => __('Alert Title' , 'rookie'),
				),
			array(
				'id' => 'Icon',
				'type'=>'icons',
				'description'=> __('Select Font', 'rookie'),
				'options'=> $font_awesome,
				),
			array(
				'id' => 'Size',
				'type'=>'select', 
				'description'=> __('Select Size', 'rookie'),
				'options'=>array(
					''  	=>__('Normal', 'rookie'),
					'fa-2x'     =>__('2x Large', 'rookie'),
					'fa-3x'     =>__('3x Large', 'rookie'),
					'fa-4x'     =>__('4x Large', 'rookie'),
					'fa-5x'     =>__('5x Large', 'rookie')
					)
				),
										
			array(
				'id' => 'Text area',
				'type'=>'textarea', 
				'description'=>__('Add Some Text', 'rookie')
				),
			array(
				'id' =>'Animation',
				'type'=>'select',
				'description'=>__('Select animation', 'rookie'),
				'options'=> $Animation,
				),
			array(
				'id' => 'Delay',
				'type'=>'text',
				'description'=> __('Delay before the animation starts in second. eg. 0.5 or 1', 'rookie'),
				),
			array(
				'id' => 'Iteration',
				'type'=>'text',
				'description'=> __('Number of times the animation is repeated. eg. 5', 'rookie'),
				),
			array(
				'id' => 'Duration',
				'type'=>'text',
				'description'=> __('Animation duration in second. eg. 0.5 or 1', 'rookie'),
				),
			
			) 
		),

	// Button
	array(
		'id' => 'Button',
		'description'=>__('Add Bootstrap Buttons', 'rookie'), 
		'fields'=> array(
			array(
				'id' => 'Size',
				'type'=>'select',
				'description'=> __('Button Size', 'rookie'),
				'options'=>array(
					''   =>'Default',
					'xlg'   	=>'Extra Large',
					'lg'   		=>'Large',
					'sm'   		=>'Small',
					'xs'   		=>'Extra Small',
					)
				),

			array(
				'id' => 'Class',
				'type'=>'select', 
				'description'=> __('Button Style', 'rookie'), 
				'options'=>array(
					'default'   =>'Default',
					'primary'   =>'Primary',
					'success'   =>'Success',
					'info'   	=>'Info',
					'warning'   =>'Warning',
					'danger'   	=>'Danger',
					'link'   	=>'Link',
					)
				),
			array(
				'id' => 'URL',
				'type'=>'text',
				'description'=> __('Add URL', 'rookie'), 
				),

			array(
				'id' => 'Text',
				'type'=>'text', 
				'description'=>__('Button Text', 'rookie')
				),
			array(
				'id' => 'Icon',
				'type'=>'icons',
				'description'=> __('Select Icon', 'rookie'),
				'options'=> $font_awesome,
				),
			array(
				'id' =>'Animation',
				'type'=>'select',
				'description'=>__('Select animation', 'rookie'),
				'options'=> $Animation,
				),
			array(
				'id' => 'Delay',
				'type'=>'text',
				'description'=> __('Delay before the animation starts in second. eg. 0.5 or 1', 'rookie'),
				),
			array(
				'id' => 'Iteration',
				'type'=>'text',
				'description'=> __('Number of times the animation is repeated. eg. 5', 'rookie'),
				),
			array(
				'id' => 'Duration',
				'type'=>'text',
				'description'=> __('Animation duration in second. eg. 0.5 or 1', 'rookie'),
				),
			) 
		),

	// Blockquote
	array(
		'id' => 'Blockquote',
		'description' => __('Add a Blockquote Content' , 'rookie'),
		'fields' => array(
			array(
				'id' => 'Text area',
				'type'=>'textarea', 
				'description'=>__('Add Some Text', 'rookie')
				),
			)
		),

	// Parallax
	array(
		'id' => 'Section Background',
		'description' => __('Add a full width background section' , 'rookie'),
		'fields' => array(
			array(
				'type'=>'desc', 
				'description' => __('Please note, this is will work only in Frontpage or Full Width Template' , 'rookie'),
				),
			array(
				'id' => 'Title',
				'type'=>'text', 
				'description'=>__('Add title', 'rookie')
				),
			array(
				'id' => 'Text area',
				'type'=>'textarea', 
				'description'=>__('Add Some Text', 'rookie')
				),
			array(
				'id' => 'Img src',
				'type'=>'text', 
				'description'=>__('Add image URL', 'rookie')
				),
			array(
				'id' => 'Button',
				'type'=>'select', 
				'description'=>__('Add button', 'rookie'),
				'options'=>array(
					'yes' 	=> 'Yes',
					'no' 	=> 'No',
					)
				),
			array(
				'id' => 'Button Class',
				'type'=>'select', 
				'description'=> __('Button Style', 'rookie'), 
				'options'=>array(
					'default'   =>'Default',
					'primary'   =>'Primary',
					'success'   =>'Success',
					'info'   	=>'Info',
					'warning'   =>'Warning',
					'danger'   	=>'Danger',
					'link'   	=>'Link',
					)
				),
			array(
				'id' => 'Button URL',
				'type'=>'text',
				'description'=> __('Add URL', 'rookie'), 
				),
			array(
				'id' => 'Button Text',
				'type'=>'text', 
				'description'=>__('Button Text', 'rookie')
				),
			array(
				'id' 	=> 'Button Icon',
				'type'	=>'icons',
				'description'=> __('Button icon', 'rookie'),
				'options'=> $font_awesome,
				),
			array(
				'id' 	=> 'Target',
				'type'	=>'select', 
				'description'=> __('Button target', 'rookie'), 
				'options'=>array(
					'blank'   	=>'_blank',
					'self'   	=>'_self',
					'parent'   	=>'_parent',
					)
				),
			)
		),

    // Divider
	array( 
		'id' => 'Divider',
		'description'=>__('Divider', 'rookie'), 
		'fields'=>array(
			array(
				'id' => 'Style',
				'type'=>'select',
				'description'=> __('Divider Style', 'rookie'), 
				'options'=>array(
					'divider-default'   =>'Default',
					'divider-shadow'    =>'Shadow Divider',
					'divider-line'      =>'Line Divider',
					)
				),
			) 
		),

	// Dropcap
	array(
		'id' => 'Dropcap',
		'description' => __('Add a Dropcap Content' , 'rookie'),
		'fields' => array(
			array(
				'id' => 'Text area',
				'type'=>'textarea', 
				'description'=>__('Add Some Text', 'rookie')
				),
			)
		),

	// array(
	// 	'id' => 'Google Maps',
	// 	'description' => __('Add a Dropcap Content' , 'rookie'),
	// 	'fields' => array(
	// 		array(
	// 			'id' => 'Width',
	// 			'type'=>'text', 
	// 			'description'=>__('Add Some Text', 'rookie')
	// 			),
	// 		array(
	// 			'id' => 'Height',
	// 			'type'=>'text', 
	// 			'description'=>__('Add Some Text', 'rookie')
	// 			),
	// 		array(
	// 			'id' => 'URL',
	// 			'type'=>'text',
	// 			'description'=> __('Add URL', 'rookie'), 
	// 			),
	// 		)
	// 	),


	// Pricing
	array(
		'id' => 'Pricing',
		'description' => __('Add a Price Tables Content' , 'rookie'),
		'fields'=>array(
			array(
				'type'=>'desc', 
				'description' => __('This shortcode will display the content created by "Pricing Tables" Post inside of your Admin Panel' , 'rookie'),
				)
			),
		),

	// progressbar
	array( 
		'id'=>'Progressbar', 
		'description'=>__('Progress Bars', 'rookie' ),
		'fields'=>array(
			array(
				'id' => 'Style',
				'type'=>'select',
				'description'=> __('Select Style', 'rookie'),
				'options'=>array(
					'primary'   =>'Primary',
					'success'   =>'Success',
					'info'   	=>'Info',
					'warning'   =>'Warning',
					'danger'   	=>'Danger',
					)
				),
			array(
				'id' => 'Strip',
				'type'=>'select',
				'description'=> __('Strip Animation', 'rookie'),
				'options'=>array(
					'yes' => 'Yes',
					'no' => 'No',
					)
				),
			array(
				'id' => 'Animate',
				'type'=>'select',
				'description'=> __('Animation', 'rookie'),
				'options'=>array(
					'yes' => 'Yes',
					'no' => 'No',
					)
				),
			array(
				'id' => 'Width',
				'type'=>'text',
				'description'=> __('Add Width Value: eg. 70', 'rookie'),
				),
			array(
				'id' => 'Content',
				'type'=>'text',
				'description'=> __('eg. WordPress', 'rookie'),
				),
			)
		),

	// portfolio
	array( 
		'id' => 'Portfolio',
		'description'=>__('Portfolio', 'rookie' ),
		'fields'=>array(
			array(
				'type'=>'desc', 
				'description' => __('This shortcode will display the content created by "Portfolio" Post inside of your Admin Panel' , 'rookie'),
				),
			array(
				'id' => 'Col',
				'type'=>'select',
				'description'=> __('Column Number', 'rookie'), 
				'options'=>array(
					'2' => '2 Columns',
					'3' => '3 Columns',
					'4' => '4 Columns',
					)
				),
			) 
		),

	// Team
	array( 
		'id' => 'Team',
		'description' => __('Add Team' , 'rookie'),
		'title'=>__('Team', 'rookie' ),
		'fields'=>array(
			array(
				'type'=>'desc', 
				'description' => __('This shortcode will display the content created by "Team" Post inside of your Admin Panel' , 'rookie'),
				)
			),
		),

	// Recent posts
	array( 
		'id'=>'Latest News',
		'description'=>__('Add Recent posts form your Blog', 'rookie'), 
		'fields'=>array(
			array(
				'type'=>'desc', 
				'description' => __('This shortcode will display the recent posts from the Blog' , 'rookie'),
				)
			),
		),

	// Recent Works
	array( 
		'id'=>'Recent Works',
		'description'=>__('Add Recent Works form your Portfolio', 'rookie'), 
		'fields'=>array(
			array(
				'id'=> 'Title',
				'type'=>'text', 
				'description'=> __('Add Title', 'rookie'),
				),
			array(
				'id'=>'Description', 
				'type'=>'textarea', 
				'description'=> __('Add Description', 'rookie'),
				),

			array(
				'id'=> 'slides',
				'type'=>'select', 
				'description'=> __('Items per Slide', 'rookie'),
				'options'=>array(
					'1' => '1 Item',
					'2' => '2 Items',
					'3' => '3 Items',
					'4' => '4 Items',
					)
				),
			)
		),

	// Service Box
	array(
		'id' => 'Service Box',
		'description'=>__('Add Content Box with Icons', 'rookie'), 
		'fields'=> array(
			array(
				'id' => 'Style',
				'type'=>'select',
				'description'=> __('Select Box Style', 'rookie'),
				'options'=>array(
					'1'  =>'Default',
					'2'  =>'Circle Icons',
					'3'  =>'Boxed',
					)
				),		
			array(
				'id' =>'Title',
				'type'=>'text',  
				'description' => __('Alert Title' , 'rookie'),
				),
			array(
				'id' => 'Text area',
				'type'=>'textarea', 
				'description'=>__('Add Some Text', 'rookie')
				),
			array(
				'id' => 'Icon',
				'type'=>'icons',
				'description'=> __('Select Icon', 'rookie'),
				'options'=> $font_awesome,
				),
			array(
				'id' => 'Icon size',
				'type'=>'select', 
				'description'=> __('Select Size', 'rookie'),
				'options'=>array(
					''  	=>__('Normal', 'rookie'),
					'fa-lg'  	=>__('Large Icon', 'rookie'),
					'fa-2x'     =>__('2x Large', 'rookie'),
					'fa-3x'     =>__('3x Large', 'rookie'),
					'fa-4x'     =>__('4x Large', 'rookie'),
					'fa-5x'     =>__('5x Large', 'rookie')
					)
				),
			array(
				'id' => 'Align',
				'type'=>'select', 
				'description'=> __('Set Align', 'rookie'),
				'options'=>array(
					'pull-left'  	=>__('Left', 'rookie'),
					'text-center'  	=>__('Center', 'rookie'),
					'pull-right'  	=>__('Right', 'rookie'),
					)
				),
			array(
				'id' => 'URL',
				'type'=>'text', 
				'description'=>__('Add Link URL', 'rookie')
				),

			array(
				'id' => 'URL Text',
				'type'=>'text',
				'description'=>__('Add URL Text', 'rookie')
				),
			array(
				'id' =>'Animation',
				'type'=>'select',
				'description'=>__('Select animation', 'rookie'),
				'options'=> $Animation,
				),
			array(
				'id' => 'Delay',
				'type'=>'text',
				'description'=> __('Delay before the animation starts in second. eg. 0.5 or 1', 'rookie'),
				),
			array(
				'id' => 'Iteration',
				'type'=>'text',
				'description'=> __('Number of times the animation is repeated. eg. 5', 'rookie'),
				),
			array(
				'id' => 'Duration',
				'type'=>'text',
				'description'=> __('Animation duration in second. eg. 0.5 or 1', 'rookie'),
				),					
			) 
		),

	// Call To Action
	array(
		'id' => 'Call to action',
		'description'=>__('Add Call to Action', 'rookie'), 
		'fields'=> array(
			array(
				'id' => 'Style',
				'type'=>'select',
				'description'=> __('Select Style', 'rookie'),
				'options'=>array(
					'1'  =>'Small Button',
					'2'  =>'Circle Button',
					)
				),
			array(
				'id' => 'Title',
				'type'=>'text',
				'description'=> __('Add Title', 'rookie'), 
				),

			array(
				'id' => 'Text Area',
				'type'=>'textarea', 
				'description'=> __('Add Some Text', 'rookie'), 
				),

			array(
				'id' => 'URL',
				'type'=>'text', 
				'description'=>__('Add Link URL', 'rookie')
				),

			array(
				'id' => 'URL Text',
				'type'=>'text',
				'description'=>__('Add URL Text', 'rookie')
				),
			array(
				'id' =>'Animation',
				'type'=>'select',
				'description'=>__('Select animation', 'rookie'),
				'options'=> $Animation,
				),
			array(
				'id' => 'Delay',
				'type'=>'text',
				'description'=> __('Delay before the animation starts in second. eg. 0.5 or 1', 'rookie'),
				),
			array(
				'id' => 'Iteration',
				'type'=>'text',
				'description'=> __('Number of times the animation is repeated. eg. 5', 'rookie'),
				),
			array(
				'id' => 'Duration',
				'type'=>'text',
				'description'=> __('Animation duration in second. eg. 0.5 or 1', 'rookie'),
				),
			) 
		),

	//Icon
	array(
		'id' => 'Icons',
		'type'=>'simple', 
		'description'=>__('Font Awesome icons v4.3', 'rookie'), 
		'fields'=>array(
			array(
				'id' => 'size',
				'type'=>'select', 
				'description'=> __('Select Size', 'rookie'),
				'options'=>array(
					''  	=>__('Normal', 'rookie'),
					'fa-lg'  	=>__('Large Icon', 'rookie'),
					'fa-2x'     =>__('2x Large', 'rookie'),
					'fa-3x'     =>__('3x Large', 'rookie'),
					'fa-4x'     =>__('4x Large', 'rookie'),
					'fa-5x'     =>__('5x Large', 'rookie')
					)
				),
			array(
				'id' => 'Spin',
				'type'=>'select', 
				'description'=> __('Spinning Animations', 'rookie'),
				'options'=>array(
					''  		=>__('No', 'rookie'),
					'fa-spin'  	=>__('Yes', 'rookie'),
					)
				),
			array(
				'id' => 'Border',
				'type'=>'select', 
				'description'=> __('Border', 'rookie'),
				'options'=>array(
					''  		 =>__('No', 'rookie'),
					'fa-border'  =>__('Yes', 'rookie'),
					)
				),
			array(
				'id' => 'Align',
				'type'=>'select', 
				'description'=> __('Set Align', 'rookie'),
				'options'=>array(
					'icons-center'  =>__('None', 'rookie'),
					'pull-left'  	=>__('Left', 'rookie'),
					'pull-right'  	=>__('Right', 'rookie'),
					)
				),											
			array(
				'id' => 'Font',
				'type'=>'icons',
				'description'=> __('Select Font', 'rookie'),
				'options'=> $font_awesome,
				)
			),

		),

);

