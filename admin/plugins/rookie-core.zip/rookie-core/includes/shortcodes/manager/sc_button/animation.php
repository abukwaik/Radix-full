<?php

/**
* @package rookie color classes
* @since rookie 1.0
* 
*/

$Animation = array(
	''			    	=> 'none',
	'bounce'       		=> 'bounce',
	'flash'    			=> 'flash',
	'pulse'    			=> 'pulse',
	'rubberBand'   		=> 'rubberBand',
	'shake'      		=> 'shake',
	'swing'    			=> 'swing',
	'tada'   			=> 'tada',
	'wobble'      		=> 'wobble',
	'bounceIn'       	=> 'bounceIn',
	'bounceInDown'    	=> 'bounceInDown',
	'bounceInLeft'    	=> 'bounceInLeft',
	'bounceInRight'  	=> 'bounceInRight',
	'bounceInUp'      	=> 'bounceInUp',
	'fadeIn'          	=> 'fadeIn',
	'fadeInDown'      	=> 'fadeInDown',
	'fadeInDownBig'   	=> 'fadeInDownBig',
	'fadeInRight'     	=> 'fadeInRight',
	'fadeInRightBig'    => 'fadeInRightBig',
	'fadeInLeft'     	=> 'fadeInLeft',
	'fadeInLeftBig'     => 'fadeInLeftBig',
	'fadeInUp'     		=> 'fadeInUp',
	'fadeInUpBig'     	=> 'fadeInUpBig', 
	'flip'     			=> 'flip',
	'flipInX'     		=> 'flipInX', 
	'flipInY'     		=> 'flipInY',
	'flipOutX'     		=> 'flipOutX',
	'flipOutY'     		=> 'flipOutY',
	'rotateIn'     		=> 'rotateIn',
	'rotateInDownLeft'  => 'rotateInDownLeft',
	'rotateInDownRight' => 'rotateInDownRight',
	'rotateInUpLeft'    => 'rotateInUpLeft',
	'rotateInUpRight'   => 'rotateInUpRight',
	'lightSpeedIn'    	=> 'lightSpeedIn',
	'slideInLeft'    	=> 'slideInLeft',
	'slideInRight'    	=> 'slideInRight',
	'rollIn'          	=> 'rollIn',
	'zoomIn'          	=> 'zoomIn',
	'zoomInDown'      	=> 'zoomInDown',
	'zoomInLeft'      	=> 'zoomInLeft',
	'zoomInRight'     	=> 'zoomInRight',  
	'zoomInUp'        	=> 'zoomInUp',
	);