
/*-----------------------------------------------------------------------------------*/
/*	Add TinyMCE List Button
/*-----------------------------------------------------------------------------------*/
(function() {  
    tinymce.create('tinymce.plugins.list', {  
        init : function(ed, url) {  
            ed.addButton('list', {  
                title : 'Arrow list',  
                image : url+'/list.png',  
                onclick : function() {  
                    ed.selection.setContent('[list]<br />[list_item] one [/list_item]<br />[list_item] tow [/list_item]<br />[list_item] three [/list_item]<br />[list_item] four [/list_item]<br />[/list]');  
  
                }  
            });  
        },  
        createControl : function(n, cm) {  
            return null;  
        },  
    });  
    tinymce.PluginManager.add('list', tinymce.plugins.list);  
})();

/*-----------------------------------------------------------------------------------*/
/*	Add TinyMCE Table Button
/*-----------------------------------------------------------------------------------*/
(function() {  
    tinymce.create('tinymce.plugins.table', {  
        init : function(ed, url) {  
            ed.addButton('table', {  
                title : 'Styled Table',  
                image : url+'/table.png',  
                onclick : function() {  
                    ed.selection.setContent('<table class="table table-striped"><thead><tr><th>#</th><th>First Name</th><th>Last Name</th><th>Username</th></tr></thead><tbody><tr><td>1</td><td>Mark</td><td>Otto</td><td>@mdo</td></tr><tr><td>2</td><td>Jacob</td><td>Thornton</td><td>@fat</td></tr><tr><td>3</td><td>Larry</td><td>the Bird</td><td>@twitter</td></tr></tbody></table>');  
                  }  
            });  
        },  
        createControl : function(n, cm) {  
            return null;  
        },  
    });  
    tinymce.PluginManager.add('table', tinymce.plugins.table);  
})();

/*-----------------------------------------------------------------------------------*/
/*  Add TinyMCE Tabs Button
/*-----------------------------------------------------------------------------------*/
(function() {  
    tinymce.create('tinymce.plugins.tabs', {  
        init : function(ed, url) {  
            ed.addButton('tabs', {  
                title : 'Add Tabs',  
                image : url+'/tabs.png',  
                onclick : function() {  
                    ed.selection.setContent('[tabgroup]<br />[tab title="Tab 1"] Tab 1 content goes here. [/tab]<br />[tab title="Tab 2"] Tab 2 content goes here. [/tab]<br />[tab title="Tab 3"] Tab 3 content goes here. [/tab]<br />[/tabgroup]');  
  
                }  
            });  
        },  
        createControl : function(n, cm) {  
            return null;  
        },  
    });  
    tinymce.PluginManager.add('tabs', tinymce.plugins.tabs);  
})();