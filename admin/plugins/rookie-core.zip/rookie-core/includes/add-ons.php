<?php 

/**
* @package Rookie Sidebar
* @since rookie 1.0
*
*/

// Post type: Sliders 
add_action('init', 'rookie_slider');
	function rookie_slider() {

	$labels = array(
		'name'                  => __( 'Slider',                'rookie' ),
		'singular_name'         => __( 'Slider',                'rookie' ),
		'menu_name'             => __( 'Sliders',               'rookie' ),
		'all_items'             => __( 'All Sliders',           'rookie' ),
		'add_new'               => __( 'Add New',               'rookie' ),
		'add_new_item'          => __( 'Add New Slider',        'rookie' ),
		'edit_item'             => __( 'Edit Slider',           'rookie' ),
		'new_item'              => __( 'New Slider',            'rookie' ),
		'view_item'             => __( 'View Slider',           'rookie' ),
		'search_items'          => __( 'Search Portfolios',     'rookie' ),
		'not_found'             => __( 'No item found',         'rookie' ),
		'not_found_in_trash'    => __( 'No item found in Trash','rookie' )
		);

	$args = array(
		'labels'                => $labels,
		'public'                => true,
		'has_archive'           => false,
		'exclude_from_search'   => true,
		'menu_icon'             => PLUGIN_IMG_URI . '/icons/icon-slider.png',
		'rewrite'               => true,
		'capability_type'       => 'post',
		'supports'              => array('title', 'page-attributes', 'editor', 'thumbnail') 
		);

	register_post_type('rookie_slider', $args);
	flush_rewrite_rules();
}


// slider metaboxes
$prefix = 'slider_';
$fields = array(
	array( 
		'label'        => __('Background Image', 'rookie'),
		'desc'         => __('Show background image in slider', 'rookie'), 
		'id'           => $prefix . 'background_image',
		'type'         => 'image'
		),

	array( 
		'label'        => __('Button Text', 'rookie'),
		'desc'         => __('Show Slider Button and Button Text', 'rookie'), 
		'id'           => $prefix . 'button_text',
		'type'         => 'text'
		),   

	array( 
		'label'        => __('Button URL', 'rookie'),
		'desc'         => __('Slider URL link.', 'rookie'), 
		'id'           => $prefix . 'button_url',
		'type'         => 'text'
		),

	array( 
		'label'        => __('Boxed Style', 'rookie'),
		'desc'         => __('Show boxed Style.', 'rookie'), 
		'id'           => $prefix . 'boxed',
		'type'         => 'select',
		'options'      => array(

			array(
				'value'=>'no',
				'label'=>__('No', 'rookie')
				),   

			array(
				'value'=>'yes',
				'label'=>__('Yes', 'rookie')
				)
	)
),
	array( 
		'label'        => __('Position', 'rookie'),
		'desc'         => __('Show slider Position.', 'rookie'), 
		'id'           => $prefix . 'position',
		'type'         => 'select',
		'options'      => array(

			array(
				'value'=>'left',
				'label'=>__('Left', 'rookie')
				),   

			array(
				'value'=>'center',
				'label'=>__('Center', 'rookie')
				),          

			array(
				'value'=>'right',
				'label'=>__('Right', 'rookie')
				),
			)
		)
	);


$fields_video = array(
	array( 
		'label'        => __('Video Type', 'rookie'),
		'desc'         => __('Select video type.', 'rookie'), 
		'id'           => $prefix . 'video_type',
		'type'         => 'radio',
		'options'      => array(
			array(
				'value'=>'',
				'label'=>__('None', 'rookie')
				),

			array(
				'value'=>'youtube',
				'label'=>__('Youtube', 'rookie')
				),   

			array(
				'value'=>'vimeo',
				'label'=>__('Vimeo', 'rookie')
				)
		)
	),

    array( 
        'label'        => __('Video Link', 'rookie'),
        'desc'         => __('Video link', 'rookie'), 
        'id'           => $prefix . 'video_link',
        'type'         => 'text'
        ), 
    );


new Custom_Add_Meta_Box( 'rookie_slider_box', __('Slider Settings', 'rookie'), $fields, 'rookie_slider', true );
new Custom_Add_Meta_Box( 'rookie_slider_box_video', __('Video Settings', 'rookie'), $fields_video, 'rookie_slider', true );

// Post type: Team 
add_action('init', 'rookie_team');
function rookie_team() {
    $labels = array(
        'name'                  => __( 'Team',                      'rookie' ),
        'singular_name'         => __( 'Team',                      'rookie' ),
        'menu_name'             => __( 'Team',                      'rookie' ),
        'all_items'             => __( 'Team Members',              'rookie' ),
        'add_new'               => __( 'Add New',                   'rookie' ),
        'add_new_item'          => __( 'Add New Member',            'rookie' ),
        'edit_item'             => __( 'Edit Member',               'rookie' ),
        'new_item'              => __( 'New Member',                'rookie' ),
        'view_item'             => __( 'View Member',               'rookie' ),
        'search_items'          => __( 'Search Member',             'rookie' ),
        'not_found'             => __( 'No Member found',           'rookie' ),
        'not_found_in_trash'    => __( 'No Member found in Trash',  'rookie' )
        );
    $args = array(
        'labels'                => $labels,
        'public'                => true,
        'has_archive'           => false,
        'exclude_from_search'   => true,
        'menu_icon'             => PLUGIN_IMG_URI . '/icons/icon-team.png',
        'rewrite'               => true,
        'capability_type'       => 'post',
        'supports'              => array('title', 'editor', 'thumbnail')
        );

    register_post_type('rookie_team', $args);
    flush_rewrite_rules();
}

// team metaboxes
$prefix = 'team_';
$fields = array(

    array( 
        'label' => __('Designation', 'rookie'), 
        'id'    => $prefix.'designation',
        'type'  => 'text'
        ),

    array( 
        'label' => __('Facebook', 'rookie'), 
        'desc'  => __('Facebook link of team member', 'rookie'), 
        'id'    => $prefix.'facebook', 
        'type'  => 'text'
        ),

    array( 
        'label' => __('Twitter', 'rookie'), 
        'desc'  => __('Twitter link of team member', 'rookie'), 
        'id'    => $prefix.'twitter', 
        'type'  => 'text'
        ),

    array( 
        'label' => __('Google Plus', 'rookie'), 
        'desc'  => __('Google Plus link of team member', 'rookie'), 
        'id'    => $prefix.'gplus', 
        'type'  => 'text'
        ),

    array( 
        'label' => __('Pinterest', 'rookie'), 
        'desc'  => __('Pinterest link of team member', 'rookie'), 
        'id'    => $prefix.'pinterest', 
        'type'  => 'text'
        ),

    array( 
        'label' => __('Linkedin', 'rookie'), 
        'desc'  => __('Linkedin link of team member', 'rookie'), 
        'id'    => $prefix.'linkedin', 
        'type'  => 'text'
        )
);

new Custom_Add_Meta_Box( 'rookie_team_box', __('Team Social Settings', 'rookie'), $fields, 'rookie_team', true );

// Post type: Price Tables 
add_action('init', 'rookie_pricing');
    function rookie_pricing() {

    $labels = array(
        'name'                      => __( 'Pricing Tables', 'rookie' ),
        'singular_name'             => __( 'Pricing Tables', 'rookie' ),
        'menu_name'                 => __( 'Pricing Tables', 'rookie' ),
        'all_items'                 => __( 'All Items', 'rookie' ),
        'add_new'                   => __( 'Add New', 'rookie' ),
        'add_new_item'              => __( 'Add New Item', 'rookie' ),
        'edit_item'                 => __( 'Edit Item', 'rookie' ),
        'new_item'                  => __( 'New Item', 'rookie' ),
        'view_item'                 => __( 'View Item', 'rookie' ),
        'search_items'              => __( 'Search Items', 'rookie' ),
        'not_found'                 => __( 'No item found', 'rookie' ),
        'not_found_in_trash'        => __( 'No item found in Trash', 'rookie' )
        );

    $args = array(
        'labels'                    => $labels,
        'public'                    => true,
        'has_archive'               => false,
        'exclude_from_search'       => true,
        'menu_icon'                 => PLUGIN_IMG_URI . '/icons/icon-pricing.png',
        'rewrite'                   => true,
        'capability_type'           => 'post',
        'supports'                  => array('title', 'page-attributes', 'editor', 'revisions')
        );

    register_post_type('rookie_pricing', $args);
    flush_rewrite_rules();
}


$prefix = 'pricing_';
$fields = array(

    array( 
        'label' => __('Featured', 'rookie'), 
        'id'    => $prefix.'featured',
        'type'  => 'checkbox'
        ),

    array( 
        'label' => __('Price', 'rookie'), 
        'desc'  => __('Price with currency symbol. eg. $49', 'rookie'), 
        'id'    => $prefix.'price', 
        'type'  => 'text'
        ),

    array( 
        'label' => __('Price duration', 'rookie'), 
        'desc'  => __('Pricing duration. eg. Moth, Day, Year etc.', 'rookie'), 
        'id'    => $prefix.'duration', 
        'type'  => 'text' 
        ),

    array( 
        'label' => __('Button Text', 'rookie'), 
        'desc'  => __('Pricing table button text, eg. Sign up', 'rookie'), 
        'id'    => $prefix.'button_text', 
        'type'  => 'text' 
        ),

    array( 
        'label' => __('Button URL', 'rookie'),
        'desc'  => __('Pricing table button url, eg. http://www.rookietheme.com/buy-now', 'rookie'),
        'id'    => $prefix.'button_url', 
        'type'  => 'text' 
        )
    );

new Custom_Add_Meta_Box( 'rookie_pricing_box', __('Price Settings', 'rookie'), $fields, 'rookie_pricing', true );


// Post type: Accordion
add_action('init', 'rookie_accordion');
    function rookie_accordion() {

    $labels = array(
        'name'                  => __( 'Accordion', 'rookie' ),
        'singular_name'         => __( 'Accordion', 'rookie' ),
        'menu_name'             => __( 'Accordion', 'rookie' ),
        'all_items'             => __( 'All Items', 'rookie' ),
        'add_new'               => __( 'Add New', 'rookie' ),
        'add_new_item'          => __( 'Add New Item', 'rookie' ),
        'edit_item'             => __( 'Edit Item', 'rookie' ),
        'new_item'              => __( 'New Item', 'rookie' ),
        'view_item'             => __( 'View Item', 'rookie' ),
        'search_items'          => __( 'Search Items', 'rookie' ),
        'not_found'             => __( 'No item found', 'rookie' ),
        'not_found_in_trash'    => __( 'No item found in Trash', 'rookie' )
        );

    $args = array(
        'labels'                => $labels,
        'public'                => true,
        'has_archive'           => false,
        'exclude_from_search'   => true,
        'menu_icon'             => PLUGIN_IMG_URI . '/icons/icon-accordion.png',
        'rewrite'               => true,
        'capability_type'       => 'post',
        'supports'              => array('title', 'editor', 'revisions')
        );


register_taxonomy('accordion-categories', 'rookie_accordion', array(
	'hierarchical'		=> true,
	'show_ui'			=> true,
	'rewrite'           => true,
	'label'             => __('Categories', 'rookie'),
	'singular_label'    => __('Category',   'rookie'), 
	));

    register_post_type('rookie_accordion', $args);
    flush_rewrite_rules();
}


// Post type: Portfolio
add_action('init', 'portfolio_init');
	function portfolio_init() {
		$custom_slug = get_option('slug') != '' ? get_option('slug') : 'portfolio';
		$args = array(
			'labels'			=> array(
			'name'				=> __('Portfolio', 'rookie'),
			'singular_name' 	=> __('Portfolio Project', 	'rookie'),
			'add_new'			=> __('Add Project', 		'rookie'),
			'add_new_item'		=> __('Add Project', 		'rookie'),
			'new_item'			=> __('Add Project', 		'rookie'),
			'view_item'			=> __('View Project', 		'rookie'),
			'search_items' 		=> __('Search Portfolio', 	'rookie'),
			'edit_item' 		=> __('Edit Project', 		'rookie'),
			'all_items'			=> __('Complete Portfolio', 'rookie'),
			'not_found'			=> __('No Projects found', 	'rookie'),
			'not_found_in_trash'=> __('No Projects found in Trash', 'rookie')
			),
			'taxonomies'		=> array('portfolio-categories', 'portfolio-skills', 'portfolio-tags'),
			'public'			=> true,
			'show_ui'			=> true,
			'_builtin'			=> false,
			'_edit_link'		=> 'post.php?post=%d',
			'capability_type'	=> 'post',
			'rewrite'			=> array('slug' => __($custom_slug)),
			'hierarchical'		=> false,
			'menu_position'		=> 20,
			// 'menu_icon' => WP_PLUGIN_URL . '/rookie/images/icon.jpg',
			'supports'			=> array('title', 'editor', 'comments', 'thumbnail')
			);
			/** create portfolio categories (taxonomy) */
		register_taxonomy('portfolio-categories', 'project', array(
			'hierarchical'		=> true,
			'show_ui'			=> true,
			'rewrite'			=> array('slug' => __($custom_slug . '/category')),
			'labels'			=> array(
			'name' 				=> __('Portfolio Categories', 					'rookie'),
			'singular_name'		=> __('Portfolio Category', 			'rookie'),
			'search_items' 		=> __('Search Portfolio Categories',	'rookie'),
			'popular_items'		=> __('Popular Portfolio Categories',	'rookie'),
			'all_items'			=> __('All Portfolio Categories', 		'rookie'),
			'parent_item'		=> __('Parent Portfolio Category', 		'rookie'),
			'parent_item_colon'	=> __('Parent Portfolio Category', 		'rookie'),
			'edit_item'			=> __('Edit Portfolio Category', 		'rookie'),
			'update_item'		=> __('Update Portfolio Category', 		'rookie'),
			'add_new_item'		=> __('Add New Portfolio Category', 	'rookie'),
			'new_item_name'		=> __('New Portfolio Category', 		'rookie'),
			'separate_items_with_commas'	=> __('Separate Portfolio Categories with commas', 	'rookie'),
			'add_or_remove_items' 	=> __('Add or remove Portfolio Categories', 				'rookie'),
			'choose_from_most_used' => __('Choose from the most used Portfolio Categories', 	'rookie')
			)
		));
		/** create portfolio clients (taxonomy) */
		register_taxonomy('portfolio-skills', 'project', array(
			'hierarchical'		=> true,
			'show_ui'			=> true,
			'query_var' 		=> true,
			'rewrite'			=> array('slug' => __($custom_slug . '/skill')),
			'labels'			=> array(
			'name' 				=> __('Skills', 			'rookie'),
			'singular_name'		=> __('Skill', 			'rookie'),
			'search_items' 		=> __('Search Skills', 	'rookie'),
			'popular_items'		=> __('Popular Skills',	'rookie'),
			'all_items'			=> __('All Skills', 		'rookie'),
			'parent_item'		=> __('Parent Skills', 		'rookie'),
			'parent_item_colon'	=> __('Parent Skills', 	'rookie'),
			'edit_item'			=> __('Edit Skills', 		'rookie'),
			'update_item'		=> __('Update Skills', 		'rookie'),
			'add_new_item'		=> __('Add New Skills', 	'rookie'),
			'new_item_name'		=> __('New Skills', 		'rookie'),
			'separate_items_with_commas'	=> __('Separate Skills with commas', 		'rookie'),
			'add_or_remove_items' 			=> __('Add or remove Skills', 				'rookie'),
			'choose_from_most_used' 		=> __('Choose from the most used Skills',	'rookie')
			)
		));
		/** create portfolio tags (taxonomy) */
		register_taxonomy('portfolio-tags', 'project', array(
			'hierarchical'		=> false,
			'show_ui'			=> true,
			'query_var' 		=> true,
			'public'			=> true,
			'rewrite'			=> array('slug' => __($custom_slug . '/tag')),
			'labels'			=> array(
			'name' 				=> __('Tags', 				'rookie'),
			'singular_name'		=> __('Tag', 			'rookie'),
			'search_items' 		=> __('Search Tags', 	'rookie'),
			'popular_items'		=> __('Popular Tags', 	'rookie'),
			'all_items'			=> __('All Tags', 		'rookie'),
			'parent_item'		=> __('Parent Tag', 	'rookie'),
			'parent_item_colon'	=> __('Parent Tag', 'rookie'),
			'edit_item'			=> __('Edit Tag', 		'rookie'),
			'update_item'		=> __('Update Tag', 	'rookie'),
			'add_new_item'		=> __('Add New Tag', 	'rookie'),
			'new_item_name'		=> __('New Tag', 		'rookie'),
			'separate_items_with_commas'	=> __('Separate Tags with commas', 	'rookie'),
			'add_or_remove_items' 	=> __('Add or remove Tags', 				'rookie'),
			'choose_from_most_used' => __('Choose from the most used Tags', 	'rookie')
			)
			));
		/** create new custom post type */
		register_post_type('portfolio', $args);
		flush_rewrite_rules();
	}

$prefix = 'portfolio_';
$fields = array(

    array( 
        'label' => __('Client name', 'rookie'), 
        'desc'  => __('Enter a client name for the current portfolio item or leave it blank', 'rookie'), 
        'id'    => $prefix.'client', 
        'type'  => 'text'
        ),

    array( 
        'label' => __('Project duration', 'rookie'), 
        'desc'  => __('Project duration. eg. 1 Month, 30 Days, etc.', 'rookie'), 
        'id'    => $prefix.'duration', 
        'type'  => 'text' 
        ),
    array( 
        'label' => __('Project Budget', 'rookie'), 
        'desc'  => __('Project Budget. eg. 10.000 USD etc.', 'rookie'), 
        'id'    => $prefix.'budget', 
        'type'  => 'text' 
        ),

    array( 
        'label' => __('Website URL', 'rookie'),
        'desc'  => __('Add Project Button url.', 'rookie'),
        'id'    => $prefix.'website_url', 
        'type'  => 'text' 
        ),
    array( 
        'label' => __('Button Text', 'rookie'), 
        'desc'  => __('Add Project Button text or leave it blank', 'rookie'), 
        'id'    => $prefix.'project_button', 
        'type'  => 'text' 
        ),    
    );

new Custom_Add_Meta_Box( 'portfolio_box', __('Project Details', 'rookie'), $fields, 'portfolio', true );