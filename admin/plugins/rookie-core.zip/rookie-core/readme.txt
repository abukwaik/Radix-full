=== Your Site's Functionality Plugin ===
Requires at least: 3.1
Tested up to: 3.1
Stable tag: 0.1

All of the important functionality of your site belongs in this. Describe what it does!

== Description ==

Plugin description, any special instructions. If nothing else, include the URL of the site that this plugin belongs to.

== Important Notes ==

= Something to remember =

Don't forget about this important thing your plugin does!

= Something else to remember =

Don't forget this other part too!

== Changelog ==
= 0.1 =
* Note what is involved in the new version. Any changes. Include a date like 05/2011.

= 0.0 =
* Don't start your plugin at 0.0. That's just dumb.